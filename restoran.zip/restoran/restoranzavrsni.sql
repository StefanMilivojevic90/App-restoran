-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 16, 2019 at 02:40 PM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restoranzavrsni`
--

-- --------------------------------------------------------

--
-- Table structure for table `artikal`
--

DROP TABLE IF EXISTS `artikal`;
CREATE TABLE IF NOT EXISTS `artikal` (
  `IDARTIKAL` int(11) NOT NULL,
  `IDTIPVRSTE` int(11) NOT NULL,
  `NAZIVARTIKLA` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `PROIZVODJACART` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `KOLICINAART` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `CENAART` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `SLIKAARTIKLA` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`IDARTIKAL`),
  UNIQUE KEY `ARTIKAL_PK` (`IDARTIKAL`),
  KEY `RELATIONSHIP_2_FK` (`IDTIPVRSTE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT;

--
-- Dumping data for table `artikal`
--

INSERT INTO `artikal` (`IDARTIKAL`, `IDTIPVRSTE`, `NAZIVARTIKLA`, `PROIZVODJACART`, `KOLICINAART`, `CENAART`, `SLIKAARTIKLA`) VALUES
(1, 2, 'Pljeskavica', '/', '200gr', '450 ', 'pljeskavica.png'),
(2, 2, 'Cevapi', '/', '250gr', '400 ', 'cevapi.png'),
(3, 2, 'Bela vesalica na kajmaku', '/', '400gr', '750', 'belavesalicakajmak.png'),
(4, 2, 'Dimljeni vrat', '/', '400gr', '800', 'dimljenivrat.png'),
(5, 2, 'Svinjska rebra na zaru', '/', '500gr', '1000', 'svinjskarebrazar.png'),
(6, 2, 'Mesano meso ', '/', '1kg', '1200', 'mesanomeso.png'),
(7, 2, 'Domaca kobasica', '/', '400gr', '600', 'domacakobasica.png'),
(8, 2, 'Leskovacki ustipci', '/', '400gr', '600', 'leskovackiustipci.png'),
(9, 2, 'Muckalica ', '/', '400gr', '680', 'muckalica.png'),
(10, 2, 'Sareni raznjici', '/', '500gr', '700', 'sareniraznjici.png'),
(11, 1, 'Teleca corba', '/', '/', '150', 'telecacorba.png'),
(12, 1, 'Pileca corba', '/', '/', '140', 'pilecacorba.png'),
(13, 1, 'Paradajz corba', '/', '/', '120', 'paradajzcorba.png'),
(14, 1, 'Domaca supa', '/', '/', '110', 'domacasupa.png'),
(15, 3, 'Pastrmka ', '/', '1kg', '1250', 'pastrmka.png'),
(16, 3, 'Dimljena pastrmka', '/', '300gr', '750', 'dimljenapastrmka.png'),
(17, 3, 'Lignje na zaru', '/', '350gr', '850', 'lignjenazaru.png'),
(18, 3, 'Som - filet', '/', '1kg', '1200', 'somfilet.png'),
(19, 3, 'Krabe ( pohovani rakovi )', '/', '250gr', '780', 'kraba.png'),
(20, 3, 'Lignje pohovane', '/', '300gr', '800', 'pohovanelignje.png'),
(21, 7, 'Palacinke sa dzemom', '/', '1 kom', '150', 'palacinkedzem.png'),
(22, 7, 'Palacinke sa eurokremom i plazmom', '/', '1 kom', '200', 'palacinkekremplazma.png'),
(23, 6, 'Krempita', '/', '1 kom', '250', 'krempita.png'),
(24, 6, 'Ledena kocka', '/', '2 kom', '240', 'ledenakocka.png'),
(25, 6, 'Tufahija', '/', '1 kom', '240', 'tufahija.png'),
(26, 6, 'Pohovani sladoled', '/', '1 kom', '200', 'pohovanisladoled.png'),
(27, 8, 'Vocna salata', '/', '1 kom', '190', 'vocnasalata.png'),
(28, 8, 'Banana split', '/', '1 kom', '250', 'bananasplit.png'),
(29, 8, 'Knedle sa sljivama', '/', '2 kom', '200', 'knedlesljiva.png'),
(30, 8, 'Vocni kup', '/', '1 kom', '230', 'vocnikup.png'),
(31, 7, 'Palacinke sa nutelom ', '/', '1 kom', '220', 'palacinkenutela.png'),
(32, 7, 'Palacinke sa nutelom i plazmom', '/', '1 kom', '240', 'palacinkenutelaplazma.png'),
(33, 4, 'Coca-cola, fanta, schweppes (flasica)', '/', '0.33 l', '130', 'cocacola.png'),
(34, 4, 'Cocta (flasica)', '/', '0.33 l', '130', 'kokta.png'),
(35, 4, 'Limunada ', '/', '0.4 l', '160', 'limunada.png'),
(36, 4, 'Cedjena pomorandza', '/', '0.4 l', '190', 'cedjenapomorandza.png'),
(37, 4, 'Kisela voda', '/', '0.33 l', '90', 'kisela.png'),
(38, 4, 'Nektar sokovi', '/', '0.2 l', '150', 'nektar.png'),
(39, 5, 'Sljivovica', '/', '0.03 l', '120', 'sljivovica.png'),
(40, 5, 'Vinjak, vodka', '/', '0.03 l', '120', 'vodka.png'),
(41, 5, 'Viljamovka ', '/', '0.03 l', '120', 'viljamovka.png'),
(42, 5, 'Loza', '/', '0.03 l', '130', 'loza.png'),
(43, 5, 'Dunja', '/', '0.03 l', '120', 'dunja.png'),
(44, 5, 'Kajsijevaca ', '/', '0.03 l', '120', 'kajsijevaca.png'),
(45, 5, 'Mednica', '/', '0.03 l', '130', 'mednica.png'),
(46, 5, 'Zuta osa', '/', '0.03 l', '170', 'zutaosa.png'),
(47, 5, 'Whisky – J Walker', '/', '0.03 l', '170', 'johnywalker.png'),
(48, 5, 'Whisky – Ballantines', '/', '0.03 l', '160', 'ballantines.png'),
(49, 5, 'Jack Daniels', '/', '0.03 l', '230', 'jack.png'),
(50, 5, 'Chivas Regal', '/', '0.03 l', '290', 'chivas.png'),
(51, 5, 'Tequilla – Two fingers', '/', '0.03 l', '150', 'tequilla.png'),
(52, 5, 'Courvoisier', '/', '0.03 l', '330', 'courvoisier.png'),
(53, 9, 'Baileys', '/', '0.03 l', '200', 'baileys.png'),
(54, 9, 'Jeger meister', '/', '0.03 l ', '160', 'jeger.png'),
(55, 9, 'Campari ', '/', '0.03 l', '160', 'campari.png'),
(56, 9, 'Martini ', '/', '0.03 l', '150', 'martini.png'),
(57, 9, 'Vermut ', '/', '0.05 l', '130', 'vermut.png'),
(58, 9, 'Sheridan’s ', '/', '0.03 l', '220', 'sheridan.png'),
(59, 11, 'Espresso ', '/', '0.2 l', '120', 'espresso.png'),
(60, 11, 'Espresso sa mlekom', '/', '0.3 l', '130', 'espressomleko.png'),
(61, 11, 'Capuccino ', '/', '0.3 l', '140', 'capuccino.png'),
(62, 11, 'Nescafe', '/', '0.4 l', '160', 'nescafe.png'),
(63, 11, 'Ice cafe', '/', '0.4 l', '190', 'icecafe.png'),
(64, 11, 'Caj sa medom', '/', '0.5 l ', '120', 'cajmed.png'),
(65, 10, 'Amstel', '/', '0.33 l', '185', 'amstel.png'),
(66, 10, 'Tuborg', '/', '0.33 l', '185', 'tuborg.png'),
(67, 10, 'Jelen pivo - toceno', '/', '0.3 l', '125', 'jelen.png'),
(68, 10, 'Jelen pivo - toceno', '/', '0.5 l', '165', 'jelenpolalitra.png'),
(69, 10, 'Lav pivo', '/', '0.4 l', '165', 'lav.png');

-- --------------------------------------------------------

--
-- Table structure for table `narudzbine`
--

DROP TABLE IF EXISTS `narudzbine`;
CREATE TABLE IF NOT EXISTS `narudzbine` (
  `IDNARUDZBINE` int(11) NOT NULL AUTO_INCREMENT,
  `BROJSTOLA` varchar(256) NOT NULL,
  PRIMARY KEY (`IDNARUDZBINE`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `narudzbine`
--

INSERT INTO `narudzbine` (`IDNARUDZBINE`, `BROJSTOLA`) VALUES
(37, '1'),
(38, '5'),
(39, '2'),
(40, '2'),
(41, '3'),
(42, '3'),
(43, '2'),
(44, ''),
(45, '5'),
(46, '3'),
(47, '2'),
(48, '6'),
(49, '3');

-- --------------------------------------------------------

--
-- Table structure for table `rezervacija`
--

DROP TABLE IF EXISTS `rezervacija`;
CREATE TABLE IF NOT EXISTS `rezervacija` (
  `IDREZERVACIJA` int(11) NOT NULL,
  `DATUMVREMEREZ` datetime DEFAULT NULL,
  `BROJGOSTIJUREZ` varchar(255) DEFAULT NULL,
  `IMEREZ` varchar(255) DEFAULT NULL,
  `SIFRAREZ` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`IDREZERVACIJA`),
  UNIQUE KEY `REZERVACIJA_PK` (`IDREZERVACIJA`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rezervacija`
--

INSERT INTO `rezervacija` (`IDREZERVACIJA`, `DATUMVREMEREZ`, `BROJGOSTIJUREZ`, `IMEREZ`, `SIFRAREZ`) VALUES
(1, '0000-00-00 00:00:00', '5', 'ime', 'sifra'),
(6, '2018-09-10 00:00:00', '2', 'aleksandar', 'vecera'),
(7, '2018-09-11 00:00:00', '9', 'Sitel', 'Team Building'),
(8, '2018-09-20 00:00:00', '3', 'Stefan', 'Rucak');

-- --------------------------------------------------------

--
-- Table structure for table `stavke_narudzbine`
--

DROP TABLE IF EXISTS `stavke_narudzbine`;
CREATE TABLE IF NOT EXISTS `stavke_narudzbine` (
  `IDSTAVKENARUDZBINE` int(11) NOT NULL AUTO_INCREMENT,
  `IDNARUDZBINE` int(11) NOT NULL,
  `IDARTIKLA` int(11) NOT NULL,
  `IMESTAVKE` varchar(255) NOT NULL,
  `KOLICINA` int(11) NOT NULL,
  `CENA` decimal(10,0) NOT NULL,
  PRIMARY KEY (`IDSTAVKENARUDZBINE`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stavke_narudzbine`
--

INSERT INTO `stavke_narudzbine` (`IDSTAVKENARUDZBINE`, `IDNARUDZBINE`, `IDARTIKLA`, `IMESTAVKE`, `KOLICINA`, `CENA`) VALUES
(57, 37, 3, 'Bela vesalica na kajmaku', 1, '750'),
(58, 37, 34, 'Cocta (flasica)', 1, '130'),
(59, 37, 26, 'Pohovani sladoled', 1, '200'),
(60, 38, 8, 'Leskovacki ustipci', 1, '600'),
(61, 38, 65, 'Amstel', 1, '185'),
(62, 38, 24, 'Ledena kocka', 2, '240'),
(63, 39, 5, 'Svinjska rebra na zaru', 1, '1000'),
(64, 40, 11, 'Teleca corba', 1, '150'),
(65, 40, 54, 'Jeger meister', 3, '160'),
(66, 40, 29, 'Knedle sa sljivama', 2, '200'),
(67, 41, 11, 'Teleca corba', 3, '150'),
(68, 41, 33, 'Coca-cola, fanta, schweppes (flasica)', 1, '130'),
(69, 41, 1, 'Pljeskavica', 1, '450'),
(70, 41, 2, 'Cevapi', 1, '400'),
(71, 42, 12, 'Pileca corba', 1, '140'),
(72, 42, 66, 'Tuborg', 1, '185'),
(73, 42, 4, 'Dimljeni vrat', 1, '800'),
(74, 44, 3, 'Bela vesalica na kajmaku', 1, '750'),
(75, 45, 6, 'Mesano meso ', 3, '1200'),
(76, 45, 36, 'Cedjena pomorandza', 2, '190'),
(77, 45, 30, 'Vocni kup', 2, '230'),
(78, 46, 15, 'Pastrmka ', 2, '1250'),
(79, 46, 40, 'Vinjak, vodka', 2, '120'),
(80, 47, 11, 'Teleca corba', 1, '150'),
(81, 48, 11, 'Teleca corba', 2, '150'),
(82, 48, 5, 'Svinjska rebra na zaru', 6, '1000'),
(83, 49, 10, 'Sareni raznjici', 52, '700');

-- --------------------------------------------------------

--
-- Table structure for table `tipvrste`
--

DROP TABLE IF EXISTS `tipvrste`;
CREATE TABLE IF NOT EXISTS `tipvrste` (
  `IDTIPVRSTE` int(11) NOT NULL,
  `IDVRSTE` int(11) NOT NULL,
  `NAZIVTIPAVRSTE` varchar(255) DEFAULT NULL,
  `SLIKA` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`IDTIPVRSTE`),
  UNIQUE KEY `TIPVRSTE_PK` (`IDTIPVRSTE`),
  KEY `RELATIONSHIP_1_FK` (`IDVRSTE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tipvrste`
--

INSERT INTO `tipvrste` (`IDTIPVRSTE`, `IDVRSTE`, `NAZIVTIPAVRSTE`, `SLIKA`) VALUES
(1, 1, 'Supe i Corbe', 'supeicorbe.png'),
(2, 1, 'Meso sa rostilja', 'mesorostilj.png'),
(3, 1, 'Riba', 'ribe.png'),
(4, 2, 'Bezalk. Pica', 'bezalkoholna.png'),
(5, 2, 'Alkoh. Pica', 'alkoholna.png'),
(6, 3, 'Torte', 'parcetorte.png'),
(7, 3, 'Palacinke', 'palacinke.png'),
(8, 3, 'Vocni desert', 'vocnikup.png'),
(9, 2, 'Likeri', 'likeri.png'),
(10, 2, 'Piva', 'piva.png'),
(11, 2, 'Topli napici', 'toplinapitak.png');

-- --------------------------------------------------------

--
-- Table structure for table `vrsta`
--

DROP TABLE IF EXISTS `vrsta`;
CREATE TABLE IF NOT EXISTS `vrsta` (
  `IDVRSTE` int(11) NOT NULL,
  `NAZIVVRSTE` varchar(255) DEFAULT NULL,
  `SLIKAVRSTE` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`IDVRSTE`),
  UNIQUE KEY `VRSTA_PK` (`IDVRSTE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vrsta`
--

INSERT INTO `vrsta` (`IDVRSTE`, `NAZIVVRSTE`, `SLIKAVRSTE`) VALUES
(1, 'Hrana', 'meso.png'),
(2, 'Pice', 'casa.png'),
(3, 'Deserti', 'torta.png');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `artikal`
--
ALTER TABLE `artikal`
  ADD CONSTRAINT `FK_ARTIKAL_RELATIONS_TIPVRSTE` FOREIGN KEY (`IDTIPVRSTE`) REFERENCES `tipvrste` (`IDTIPVRSTE`);

--
-- Constraints for table `tipvrste`
--
ALTER TABLE `tipvrste`
  ADD CONSTRAINT `FK_TIPVRSTE_RELATIONS_VRSTA` FOREIGN KEY (`IDVRSTE`) REFERENCES `vrsta` (`IDVRSTE`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
