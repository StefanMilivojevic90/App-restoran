<?php
	session_start();
	
	include("config.php");

	if(isset($_POST['brStola'])){
		$brStola = $_POST["brStola"];
	}
	
	$upit = "INSERT INTO `narudzbine` VALUES(NULL, '$brStola')";
	$res = mysqli_query($conn, $upit);

	$idNarudzbine = mysqli_insert_id($conn);

	// echo "$upit";

	if(!$res){
		echo "Greska u drugiUp";
	}

	foreach ($_SESSION['narudzbina'] as $key => $stavka) {

		$upit = "INSERT INTO `stavke_narudzbine` VALUES(NULL, ".$idNarudzbine.", ".$stavka['artikal_id'].", '".$stavka['artikal_naziv']."', ".intval($stavka['kolicina']).", ".intval($stavka['cena']).")";
		$res = mysqli_query($conn, $upit);
	}

	unset($_SESSION['narudzbina']);



 HEADER('Location:index.php'); 

?>