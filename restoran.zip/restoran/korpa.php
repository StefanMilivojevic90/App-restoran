<!DOCTYPE html>
<html>
<head>
		<script src="jquery-3.2.1.min.js"></script>
		<script src="skripta.js"></script>
	<style>
		/*.meni {
			text-align: center;
		    border: 3px solid blue;
		    border-style: ridge;
		    border-radius: 15px 50px;
		    background-color: lightblue;
		    width: 300px;
		}
		.nazivArtikla {
			color: red;
		}
		.inputPolje {
			margin: 10px 10px 10px 35px;
		}
		h2 {
			text-align: center;
		    background-color: lightblue;
		    width: 300px;
		    color: blue;
		}*/

	</style>
</head>
<body>

</body>
</html>

<?php

	include('config.php');

	if(isset($_SESSION['narudzbina'])) {
		echo "<h2 class='narudzbinaTitle'>Vaša narudžbina:</h2>";
		
		foreach ($_SESSION['narudzbina'] as $key => $stavka) {

		echo "<div class='group'>";

		echo "	<div class = 'meni meniNarucen'>
				<h1 class='nazivArtikla'>".$stavka['artikal_naziv']."</h1>
				<h2>Količina: ".$stavka['kolicina']."</h2>
				<h2>Cena: ".$stavka['cena']*$stavka['kolicina']." dinara</h2>
				<button id = 'sakrijNar' style='color: blue' data-key = '".$key."'>Otkaži</button> 
				</div>
			";
	    }

	    echo "</div>";

	 	echo "<div class='stoPolje'>
				<form method = 'POST' action = 'naruci.php'>
				Broj stola: <input type = 'text' name = 'brStola' id = 'brStola'>
				<button type='submit' style='color: red'>Naruči</button>
				</form>
				</div>";
	}
?>