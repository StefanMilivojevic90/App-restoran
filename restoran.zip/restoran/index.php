<?php 
session_start();
?>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="style-new.css">
		<link rel="stylesheet" type="text/css" href="animate.css">
		<script src="jquery-3.2.1.min.js"></script>
		<script src="skripta.js"></script>
		<script src="wow.min.js"></script>
		<script>
			new WOW().init();
		</script>
	</head>
	<body>
		<div id="wrapper">
			<h1 class="naslov">~ kuhinjica ~</h1>
			<div id="header">
				<?php
					include("loadAllVrste.php");
				?>
			</div>
			<div id="body">
			</div>
			<div id="korpa">
				<?php
					include("korpa.php");
				?>
			</div>
			<div id="reservation">
				<h3 id="naslovZaRez">Rezervišite vaš sto</h3>
				<div class="bodyZaRez">
					<p style="color: red; font-size: 15px; color: purple"><strong><i>Unesite datum, vreme i broj gostiju</i></strong></p>
					<form action="rezervacija.php" method="POST" class="res-form">
						<div class="datumArt">
					       <label for="datum" class="control-label" style="font-size: 11px;"><strong><i>Današnji datum:</strong><i></label>
					       <input type="date" class="form-control" id="datum" name="datum" value="" required="" title="Please enter you Name" placeholder="Današnji datum"/>
					   	</div>
					    <span class="help-block"></span><br/>
					    <div class="brojGostiju">
					    	<label for="brojGostiju" style="font-size: 11px;"><strong><i>Broj gostiju:</i></strong></label>
							<input type="text" id="brojGostiju" name="brojGostiju" placeholder="Broj gostiju"/>
						</div><br/>
						<div class="imeRez">
					    	<label for="imeRez" style="font-size: 11px;"><strong><i>Ime rezervacije:</i></strong></label>
							<input type="text" id="imeRez" name="imeRez" placeholder="Ime na koje rezervisete"/>
						</div><br/>
						<div class="sifraRez">
					    	<label for="sifraRez" style="font-size: 11px;"><strong><i>Šifra rezervacije:</i></strong></label>
							<input type="text" id="sifraRez" name="sifraRez" placeholder="Sifra rezervacije"/>
						</div><br/>
						<input type="submit" name="submit" value="Rezervišite" class="dugmeRez"/>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>