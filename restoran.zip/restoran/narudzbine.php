<?php
		
		session_start();
include("config.php");

	if(isset($_POST['idArtikal'])){
		$idArtikal = $_POST["idArtikal"];
	}

	$sql = "SELECT *
			FROM artikal 
			WHERE IDARTIKAL = '$idArtikal'";
	$rezTabela = mysqli_query($conn, $sql);

	if(!$rezTabela){
		echo "tabela";
	}	

	$red = mysqli_fetch_assoc($rezTabela);
	$nazivArt = $red["NAZIVARTIKLA"];


	if(isset($_POST['kolicina'])){
		$kolicina = $_POST['kolicina'];
			
		$_SESSION['narudzbina'][] = [
			'artikal_id' => $idArtikal,
			'artikal_naziv' => $nazivArt,
			'kolicina' => $kolicina,
			'cena' => $red['CENAART']
		];

	/*	$query="SELECT MAX(IDNARUDZBINE)+1 as nextID FROM narudzbine";
		$rezultat= mysqli_query($conn, $query);
		if(!$rezultat){
			echo "greska u prvom upitu";
		} 
		$row=mysqli_fetch_assoc($rezultat); 
		$nextID = $row["nextID"];

	
	$upit = "INSERT INTO `narudzbine`(`IDNARUDZBINE`, `NARUDZBINA`, `BROJSTOLA`) VALUES($nextID,'$nazivArt', '$brStola')";
	$res = mysqli_query($conn, $upit);

	echo "$upit";*/
	
	// echo "<pre>";
	// print_r($res);
	// die();

	// if(!$res){
	// 	echo "Greska u drugiUp";
	// }
	}

	header('Location:index.php'); 
?>