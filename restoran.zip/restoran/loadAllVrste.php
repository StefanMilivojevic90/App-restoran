<!-- <div class="group"> -->
<?php
	include('config.php');

	$upit = "SELECT * FROM vrsta";
	
	$rezTabela = mysqli_query($conn, $upit);
	
	if(!$rezTabela) {
		die('Error');
	}
	

	echo "<div class='group'>";

	while($row = mysqli_fetch_assoc($rezTabela)) {
		$id = $row['IDVRSTE'];
		$naziv = $row['NAZIVVRSTE'];
		$slika = $row['SLIKAVRSTE'];
		
		echo "<div class='vrstaDiv wow fadeIn'>
					<div class='vrstaPic'>
						<img src='pics/$slika' onclick = 'showAllTipVrste($id)' ></img>
					</div>
					<h3 class='nazivVrste'>$naziv</h3>
				</div>
			";
		}
	echo "</div>";
?>