<!DOCTYPE html>
<html>
<head>
	<style>
/*		.meni {
			text-align: center;
		    border: 3px solid blue;
		    border-style: ridge;
		    border-radius: 15px 50px;
		    background-color: lightblue;
		    width: 300px;
		}
		.nazivArtikla {
			color: red;
		}
		.inputPolje {
			margin: 10px 10px 10px 35px;
		}
		h2 {
			text-align: center;
		    background-color: lightblue;
		    width: 300px;
		    color: blue;
		}
*/
	</style>
</head>
<body>

</body>
</html>

<?php

	if(isset($_POST['idTipVrste'])){
 
	$idTipVrste =intval($_POST['idTipVrste']);
 
	include('config.php');
	
	$upit ="SELECT * FROM artikal
			WHERE idTipVrste = $idTipVrste";
	
	$rezTabela = mysqli_query($conn, $upit);
	
	if(!$rezTabela) {
		die('Error');
	}
	
	echo "<div class='group'>";

	while($row = mysqli_fetch_assoc($rezTabela)) {
		$idArtikal = $row['IDARTIKAL'];
		$nazivArtikla = $row['NAZIVARTIKLA'];
		$proizvodjac = $row['PROIZVODJACART'];
		$kolicina = $row['KOLICINAART'];
		$cena = $row['CENAART'];
		$slikaArtikla = $row['SLIKAARTIKLA'];
		
		echo "	<div class = 'meni'>
					<img src='pics/$slikaArtikla' class='slikaArtikla'>
					<h1 class='nazivArtikla'>$nazivArtikla</h1>
					<h3 class='kolicinaArtikla'>Količina: $kolicina</h3>
					<h3 class='cenaArtikla'>Cena: $cena dinara</h3>
					<div class='inputPolje'>
					<form method = 'POST' action = 'narudzbine.php'>
					Komada: <input type = 'text' name = 'kolicina' id = 'kolicina'>
					<input type = 'hidden' name = 'idArtikal' id = 'idArtikal' value='".$idArtikal."'>
					<button type='submit' style='color: red; margin-top: 15px' >Naruči</button>
					</form>
					</div>
				</div>
			";
	}

	echo "</div>";
 }
?>