/*$(document).ready(function(){
	function vrsteTipa(id) {
		$.ajax({
				url:'vrsteHrane.php',
				method: 'POST',
				data: {
					'vrste': id
				},
				dataType: 'json',
				success: function(nizObj){
					for(var i = 0; i < nizObj.length; i++) {
						console.log(nizObj[i]);
					}
				},
				error: function(){
					console.log('Error');
				}
		});
	}
});*/

$(document).ready(function() {
	
});
	
function showAllTipVrste(id) {
	$.ajax({
			url:'vrsteHrane.php',
			method: 'POST',
			data: {
				'idVrste': id
			},
			dataType: 'text',
			success: function(respond){
				$("#body").html(respond);
			},
			error: function(){
				console.log('Error iz Ajaksa');
			}
		});
}

function showArtikal(id) {
	$.ajax({
			url:'vrsteRostilja.php',
			method: 'POST',
			data: {
				'idTipVrste': id
			},
			dataType: 'text',
			success: function(respond){
				$("#body").html(respond);
			},
			error: function(){
				console.log('Error iz Ajaksa');
			}
		});
	}	


/*$(document).on("click","#prvi",function(){
	var prvi = $('#prvi').val();
	$.ajax({
		url : "rezervacija.php",
		method : "POST",
		data: {
			'funkcija': 'rezervacija',
			'rezervacija': 'brojStola',
			'brojStola': prvi
		},
		dataType: "text",
		success:function(respond){
			$("#wrapper").fadeOut(500, function(){
					$("#wrapper").load("loadAllVrste.php");
				});
		},
		error: function(){
			console.log("Fail neki.")
		}
	});
});

$(document).on("click","#drugi",function(){
	var drugi = $('#drugi').val();
	$.ajax({
		url : "rezervacija.php",
		method : "POST",
		data: {
			'rezervacija': 'brojStola',
			'brojStola': drugi
		},
		dataType: "text",
		success:function(respond){
			$("#wrapper").fadeOut(500, function(){
					$("#wrapper").load("rezervacija.php");
				});
		},
		error: function(){
			console.log("Fail neki.")
		}
	});
});

$(document).on("click","#treci",function(){
	var treci = $('#treci').val();
	$.ajax({
		url : "rezervacija.php",
		method : "POST",
		data: {
			'rezervacija': 'brojStola',
			'brojStola': treci
		},
		dataType: "text",
		success:function(respond){
			$("#wrapper").fadeOut(500, function(){
					$("#wrapper").load("rezervacija.php");
				});
		},
		error: function(){
			console.log("Fail neki.")
		}
	});
});  */

function naruci(idArtikal){
	location.assign('narudzbine.php?idArtikal='+idArtikal);
}


$(document).on("click", "#sakrijNar", function(){
	var key = $(this).attr('data-key');
	$(this).parent().remove();
	$.ajax({
			url:'izbrisiIzKorpe.php',
			method: 'POST',
			data: {
				'key': key
			},
			dataType: 'text',
			success: function(respond){
				location.reload();
			},
			error: function(){
				console.log('Error iz Ajaksa');
			}
		});

});

