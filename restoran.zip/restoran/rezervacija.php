<?php

	include("config.php");

	if(isset($_POST['submit'])){
		$datum = $_POST["datum"];
		$brojGostiju = $_POST["brojGostiju"];
		$imeRez = $_POST["imeRez"];
		$sifraRez = $_POST["sifraRez"];

		$query="SELECT MAX(IDREZERVACIJA)+1 as nextID FROM rezervacija";
		$res= mysqli_query($conn, $query);/* izvrsi konekciju nad upitom (izvrsi upit) */

		if(!$res){
			die("greska u prvom upitu");
		}

		$red=mysqli_fetch_assoc($res);
		$nextID = $red["nextID"];
		if($nextID == ''){
			$nextID = '1';
		}
		$upit= "INSERT INTO `rezervacija` (`IDREZERVACIJA`, `DATUMVREMEREZ`, `BROJGOSTIJUREZ`, `IMEREZ`, `SIFRAREZ`) VALUES ($nextID, '$datum', '$brojGostiju', '$imeRez', '$sifraRez')";

		$rez= mysqli_query($conn, $upit);

		if(!$rez){
			die("greška u upitu");
		}HEADER('Location: index.php');
	}
	else {
		die('nema isset get submit');
	}
?>