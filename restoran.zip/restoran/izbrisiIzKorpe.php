<?php
	session_start();
	if(isset($_POST['key'])){
		$key = $_POST['key'];
		if(isset($_SESSION['narudzbina'][$key])){
			unset($_SESSION['narudzbina'][$key]);
		}	
	}
?>