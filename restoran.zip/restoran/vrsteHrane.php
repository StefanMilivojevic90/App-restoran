<!DOCTYPE html>
<html>
<head>
</head>
<body>

</body>
</html>

<?php
 
 if(isset($_POST['idVrste'])){
 
	$idVrste = intval($_POST['idVrste']);
 
	include('config.php');
	
	$upit = "SELECT * FROM tipVrste where idVrste = $idVrste";
	
	$rezTabela = mysqli_query($conn, $upit);
	
	if(!$rezTabela) {
		die('Error');
	}

	echo "<div class='group'>";
	
	while($row = mysqli_fetch_assoc($rezTabela)) {
		$id = $row['IDTIPVRSTE'];
		$naziv = $row['NAZIVTIPAVRSTE'];
		$slika = $row['SLIKA'];
		
		echo"<div class='tipDiv'>
				<div class='tipPic'>
					<img src='pics/$slika' onclick = 'showArtikal($id)' alt='$naziv'></img>
				</div>
				<h4 class='nazivTipa'>$naziv</h4>
			</div>
			";
	}

	echo "</div>";
 
} 
?>